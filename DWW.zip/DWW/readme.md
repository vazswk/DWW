# DWW: Robust Deep Wavelet-domain Watermarking with Enhanced Frequency Mask

Code, model, and supplementary material containing more details and experiments are still being continuously organized

## Installation

- Clone repo and install submodules

```
git clone --recurse-submodules https://github.com/vazswk/DWW.git
cd dww
```

- Install tensorflow (tested with tf 1.13)
- Python 3 required
- bchlib 0.14.0

# To train the network

python train.py exp_name

PS: The training is performed in `train.py`. There are a number of hyperparameters, many corresponding to the augmentation parameters. 

# To use the pre-trained model 

# Download link of pre-trained model：https://drive.google.com/file/d/1fOTdy6tHnZzhw2_sHhtyYeUfRKcOG94X/view?usp=drive_link

python encode_image.py Model_name --images_dir '.../'

python decode_image.py Model_name --images_dir '.../'





PS: After screen shooting process, please first utilize the ``PespectiveTransformation.m‘’ to make a perspective correction. Special thanks to PIMoG for the matlab code. 

Although we aim for smooth execution, we cannot guarantee that the code will run without requiring debugging. To replicate or use the code, ensure all prerequisites are in place. Once everything is prepared, modify the hyperparameters and execute the test or main file. Debugging may still be necessary to resolve any issues that arise. 
If you notice any missing files or encounter difficulties, please do not hesitate to contact us for assistance.