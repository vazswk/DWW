import numpy as np
import tensorflow as tf
from tensorflow.python.keras.layers import *
import pywt


class DWT_1D(Layer):
    """

    """

    def __init__(self, wavename):
        super(DWT_1D, self).__init__()
        wavelet = pywt.Wavelet(wavename)
        self.band_low = wavelet.rec_lo
        self.band_high = wavelet.rec_hi
        assert len(self.band_low) == len(self.band_high)
        self.band_length = len(self.band_low)
        assert self.band_length % 2 == 0
        self.band_length_half = np.floor(self.band_length / 2)

    def get_matrix(self):
        L1 = self.input_height
        L = np.floor(L1 / 2)
        matrix_h = np.zeros((L, L1 + self.band_length - 2))
        matrix_g = np.zeros((L1 - L, L1 + self.band_length - 2))
        end = None if self.band_length_half == 1 else (-self.band_length_half + 1)
        index = 0
        for i in range(L):
            for j in range(self.band_length):
                matrix_h[i, index + j] = self.band_low[j]
            index += 2
        index = 0
        for i in range(L1 - L):
            for j in range(self.band_length):
                matrix_g[i, index + j] = self.band_high[j]
            index += 2
        matrix_h = matrix_h[:, (self.band_length_half - 1):end]
        matrix_g = matrix_g[:, (self.band_length_half - 1):end]
        self.matrix_low = tf.cast(matrix_h, dtype=tf.float32)
        self.matrix_high = tf.cast(matrix_g, dtype=tf.float32)

    def call(self, inputs, **kwargs):
        assert len(inputs.shape) == 3
        self.input_height = int(inputs.shape[-2])
        self.get_matrix()
        L = tf.matmul(inputs, self.matrix_low)
        H = tf.matmul(inputs, self.matrix_high)
        return L, H


class IDWT_1D(Layer):
    """

    """

    def __init__(self, wavename):
        super(IDWT_1D, self).__init__()
        wavelet = pywt.Wavelet(wavename)
        self.band_low = wavelet.dec_lo
        self.band_high = wavelet.dec_hi
        self.band_low.reverse()
        self.band_high.reverse()
        assert len(self.band_low) == len(self.band_high)
        self.band_length = len(self.band_low)
        assert self.band_length % 2 == 0
        self.band_length_half = np.floor(self.band_length / 2)

    def get_matrix(self):
        L1 = self.input_height
        L = np.floor(L1 / 2)
        matrix_h = np.zeros((L, L1 + self.band_length - 2))
        matrix_g = np.zeros((L1 - L, L1 + self.band_length - 2))
        end = None if self.band_length_half == 1 else (-self.band_length_half + 1)
        index = 0
        for i in range(L):
            for j in range(self.band_length):
                matrix_h[i, index + j] = self.band_low[j]
            index += 2
        index = 0
        for i in range(L1 - L):
            for j in range(self.band_length):
                matrix_g[i, index + j] = self.band_high[j]
            index += 2
        matrix_h = matrix_h[:, (self.band_length_half - 1):end]
        matrix_g = matrix_g[:, (self.band_length_half - 1):end]
        self.matrix_low = tf.cast(matrix_h, dtype=tf.float32)
        self.matrix_high = tf.cast(matrix_g, dtype=tf.float32)

    def call(self, L, H):
        assert len(L.shape) == len(H.shape) == 3
        self.input_height = int(L.shape[-2]) + int(H.shape[-2])
        self.get_matrix()
        output = tf.matmul(L, self.matrix_low) + tf.matmul(H, self.matrix_high)
        return output


class DWT_2D(Layer):
    """

    """

    def __init__(self, wavename):
        super(DWT_2D, self).__init__()
        wavelet = pywt.Wavelet(wavename)
        self.band_low = wavelet.rec_lo
        self.band_high = wavelet.rec_hi
        assert len(self.band_low) == len(self.band_high)
        self.band_length = len(self.band_low)
        assert self.band_length % 2 == 0
        self.band_length_half = int(np.floor(self.band_length / 2))

    def get_matrix(self):
        L1 = self.input_height
        L = int(np.floor(L1 / 2))
        matrix_h = np.zeros((L, L1 + self.band_length - 2))
        matrix_g = np.zeros((L1 - L, L1 + self.band_length - 2))
        end = None if self.band_length_half == 1 else (-self.band_length_half + 1)
        index = 0
        for i in range(L):
            for j in range(self.band_length):
                matrix_h[i, index + j] = self.band_low[j]
            index += 2
        matrix_h_0 = matrix_h[0:int(np.floor(self.input_height / 2)), 0:(self.input_height + self.band_length - 2)]
        matrix_h_1 = matrix_h[0:int(np.floor(self.input_width / 2)), 0:(self.input_width + self.band_length - 2)]
        index = 0
        for i in range(L1 - L):
            for j in range(self.band_length):
                matrix_g[i, index + j] = self.band_high[j]
            index += 2
        matrix_g_0 = matrix_g[0:int(self.input_height - np.floor(self.input_height / 2)),
                     0:(self.input_height + self.band_length - 2)]
        matrix_g_1 = matrix_g[0:int(self.input_width - np.floor(self.input_width / 2)),
                     0:(self.input_width + self.band_length - 2)]

        matrix_h_0 = matrix_h_0[:, (self.band_length_half - 1):end]
        matrix_h_1 = matrix_h_1[:, (self.band_length_half - 1):end]
        matrix_h_1 = np.transpose(matrix_h_1)
        matrix_g_0 = matrix_g_0[:, (self.band_length_half - 1):end]
        matrix_g_1 = matrix_g_1[:, (self.band_length_half - 1):end]
        matrix_g_1 = np.transpose(matrix_g_1)

        self.matrix_low_0 = tf.expand_dims(tf.expand_dims(tf.cast(matrix_h_0, dtype=tf.float32), 0), 0)
        self.matrix_low_1 = tf.expand_dims(tf.expand_dims(tf.cast(matrix_h_1, dtype=tf.float32), 0), 0)
        self.matrix_high_0 = tf.expand_dims(tf.expand_dims(tf.cast(matrix_g_0, dtype=tf.float32), 0), 0)
        self.matrix_high_1 = tf.expand_dims(tf.expand_dims(tf.cast(matrix_g_1, dtype=tf.float32), 0), 0)

    def call(self, inputs, **kwargs):
        assert len(inputs.shape) == 4
        self.input_height = int(inputs.shape[1])
        self.input_width = int(inputs.shape[2])
        self.get_matrix()
        inputs = tf.transpose(inputs, [0, 3, 1, 2])
        enlarge = tf.ones_like(tf.reduce_min(inputs, axis=[-2, -1], keepdims=True))
        L = tf.matmul(self.matrix_low_0 * enlarge, inputs)
        H = tf.matmul(self.matrix_high_0 * enlarge, inputs)
        LL = tf.transpose(tf.matmul(L, self.matrix_low_1 * enlarge), [0, 2, 3, 1])
        LH = tf.transpose(tf.matmul(L, self.matrix_high_1 * enlarge), [0, 2, 3, 1])
        HL = tf.transpose(tf.matmul(H, self.matrix_low_1 * enlarge), [0, 2, 3, 1])
        HH = tf.transpose(tf.matmul(H, self.matrix_high_1 * enlarge), [0, 2, 3, 1])
        return LL, LH, HL, HH


class DWT_2D_simple(Layer):
    """

    """

    def __init__(self, wavename):
        super(DWT_2D_simple, self).__init__()
        wavelet = pywt.Wavelet(wavename)
        self.band_low = wavelet.rec_lo
        self.band_high = wavelet.rec_hi
        assert len(self.band_low) == len(self.band_high)
        self.band_length = len(self.band_low)
        assert self.band_length % 2 == 0
        self.band_length_half = int(np.floor(self.band_length / 2))

    def get_matrix(self):
        L1 = self.input_height
        L = int(np.floor(L1 / 2))
        matrix_h = np.zeros((L, L1 + self.band_length - 2))
        end = None if self.band_length_half == 1 else (-self.band_length_half + 1)
        index = 0
        for i in range(L):
            for j in range(self.band_length):
                matrix_h[i, index + j] = self.band_low[j]
            index += 2
        matrix_h_0 = matrix_h[0:int(np.floor(self.input_height / 2)), 0:(self.input_height + self.band_length - 2)]
        matrix_h_1 = matrix_h[0:int(np.floor(self.input_width / 2)), 0:(self.input_width + self.band_length - 2)]

        matrix_h_0 = matrix_h_0[:, (self.band_length_half - 1):end]
        matrix_h_1 = matrix_h_1[:, (self.band_length_half - 1):end]
        matrix_h_1 = np.transpose(matrix_h_1)

        self.matrix_low_0 = tf.expand_dims(tf.expand_dims(tf.cast(matrix_h_0, dtype=tf.float32), 0), 0)
        self.matrix_low_1 = tf.expand_dims(tf.expand_dims(tf.cast(matrix_h_1, dtype=tf.float32), 0), 0)

    def call(self, inputs, **kwargs):
        assert len(inputs.shape) == 4
        self.input_height = int(inputs.shape[1])
        self.input_width = int(inputs.shape[2])
        self.get_matrix()
        inputs = tf.transpose(inputs, [0, 3, 1, 2])
        enlarge = tf.ones_like(tf.reduce_min(inputs, axis=[-2, -1], keepdims=True))
        L = tf.matmul(self.matrix_low_0 * enlarge, inputs)
        LL = tf.transpose(tf.matmul(L, self.matrix_low_1 * enlarge), [0, 2, 3, 1])
        return LL


class IDWT_2D(Layer):
    """

    """

    def __init__(self, wavename):
        super(IDWT_2D, self).__init__()
        wavelet = pywt.Wavelet(wavename)
        self.band_low = wavelet.dec_lo
        self.band_low.reverse()
        self.band_high = wavelet.dec_hi
        self.band_high.reverse()
        assert len(self.band_low) == len(self.band_high)
        self.band_length = len(self.band_low)
        assert self.band_length % 2 == 0
        self.band_length_half = int(np.floor(self.band_length / 2))

    def get_matrix(self):
        L1 = self.input_height
        L = int(np.floor(L1 / 2))
        matrix_h = np.zeros((L, L1 + self.band_length - 2))
        matrix_g = np.zeros((L1 - L, L1 + self.band_length - 2))
        end = None if self.band_length_half == 1 else (-self.band_length_half + 1)
        index = 0
        for i in range(L):
            for j in range(self.band_length):
                matrix_h[i, index + j] = self.band_low[j]
            index += 2
        matrix_h_0 = matrix_h[0:int(np.floor(self.input_height / 2)), 0:(self.input_height + self.band_length - 2)]
        matrix_h_1 = matrix_h[0:int(np.floor(self.input_width / 2)), 0:(self.input_width + self.band_length - 2)]
        index = 0
        for i in range(L1 - L):
            for j in range(self.band_length):
                matrix_g[i, index + j] = self.band_high[j]
            index += 2
        matrix_g_0 = matrix_g[0:int(self.input_height - np.floor(self.input_height / 2)),
                     0:(self.input_height + self.band_length - 2)]
        matrix_g_1 = matrix_g[0:int(self.input_width - np.floor(self.input_width / 2)),
                     0:(self.input_width + self.band_length - 2)]

        matrix_h_0 = matrix_h_0[:, (self.band_length_half - 1):end]
        matrix_h_1 = matrix_h_1[:, (self.band_length_half - 1):end]
        matrix_h_0 = np.transpose(matrix_h_0)
        matrix_g_0 = matrix_g_0[:, (self.band_length_half - 1):end]
        matrix_g_1 = matrix_g_1[:, (self.band_length_half - 1):end]
        matrix_g_0 = np.transpose(matrix_g_0)

        self.matrix_low_0 = tf.expand_dims(tf.expand_dims(tf.cast(matrix_h_0, dtype=tf.float32), 0), 0)
        self.matrix_low_1 = tf.expand_dims(tf.expand_dims(tf.cast(matrix_h_1, dtype=tf.float32), 0), 0)
        self.matrix_high_0 = tf.expand_dims(tf.expand_dims(tf.cast(matrix_g_0, dtype=tf.float32), 0), 0)
        self.matrix_high_1 = tf.expand_dims(tf.expand_dims(tf.cast(matrix_g_1, dtype=tf.float32), 0), 0)

    def call(self, LL, LH, HL, HH):
        assert len(LL.shape) == len(LH.shape) == len(HL.shape) == len(HH.shape) == 4
        self.input_height = int(LL.shape[-3]) + int(HH.shape[-3])
        self.input_width = int(LL.shape[-2]) + int(HH.shape[-2])
        self.get_matrix()
        LL = tf.transpose(LL, [0, 3, 1, 2])
        LH = tf.transpose(LH, [0, 3, 1, 2])
        HL = tf.transpose(HL, [0, 3, 1, 2])
        HH = tf.transpose(HH, [0, 3, 1, 2])
        enlarge = tf.ones_like(tf.reduce_min(LL, axis=[-2, -1], keepdims=True))
        L = tf.matmul(LL, self.matrix_low_1 * enlarge) + tf.matmul(LH, self.matrix_high_1 * enlarge)
        H = tf.matmul(HL, self.matrix_low_1 * enlarge) + tf.matmul(HH, self.matrix_high_1 * enlarge)
        output = tf.transpose(tf.matmul(self.matrix_low_0 * enlarge, L) + tf.matmul(self.matrix_high_0 * enlarge, H),
                              [0, 2, 3, 1])
        return output


class Down_DWT_Block(Layer):
    """

    """

    def __init__(self, channels, wavename='haar', activation='relu', padding='same', kernel_initializer='he_normal'):
        super(Down_DWT_Block, self).__init__()
        self.dwt = DWT_2D(wavename=wavename)
        # self.conv1 = Conv2D(channels, 1, padding=padding, activation=activation,
        #                     kernel_initializer=kernel_initializer)
        self.conv3 = Conv2D(channels, 3, padding=padding, activation=activation,
                            kernel_initializer=kernel_initializer)

    def call(self, input):
        LL, LH, HL, HH = self.dwt(input)
        # L = self.conv1(LL)
        H = concatenate([LL, LH, HL, HH], axis=3)
        H = self.conv3(H)
        return LL, H


class Up_IDWT_Block(Layer):
    """

    """

    def __init__(self, channels, wavename='haar', activation='relu', padding='same', kernel_initializer='he_normal'):
        super(Up_IDWT_Block, self).__init__()
        self.idwt = IDWT_2D(wavename=wavename)
        self.conv_lh = Conv2D(channels, 3, padding=padding, activation=activation,
                              kernel_initializer=kernel_initializer)
        self.conv_hl = Conv2D(channels, 3, padding=padding, activation=activation,
                              kernel_initializer=kernel_initializer)
        self.conv_hh = Conv2D(channels, 3, padding=padding, activation=activation,
                              kernel_initializer=kernel_initializer)

    def call(self, LL, input):
        LH = self.conv_lh(input)
        HL = self.conv_hl(input)
        HH = self.conv_hh(input)
        return self.idwt(LL, LH, HL, HH)


class DWT_Block(Layer):
    """

    """

    def __init__(self, channels, wavename='haar', activation='relu', padding='same', kernel_initializer='he_normal'):
        super(DWT_Block, self).__init__()
        self.dwt = DWT_2D(wavename=wavename)
        self.conv1 = Conv2D(channels, 3, padding=padding, activation=activation,
                            kernel_initializer=kernel_initializer)
        self.conv2 = DWT_IDWT_Block(channels, wavename='haar', padding=padding, activation=activation,
                                    kernel_initializer=kernel_initializer)
        self.conv3 = DWT_IDWT_Block(channels, wavename='haar', padding=padding, activation=activation,
                                    kernel_initializer=kernel_initializer)
        self.conv4 = DWT_IDWT_Block(channels, wavename='haar', padding=padding, activation=activation,
                                    kernel_initializer=kernel_initializer)

    def call(self, inputs, secret=None):
        LL, LH, HL, HH = self.dwt(inputs)
        # if secret is not None:
        #     LL = concatenate([LL, secret], axis=3)
        #     LH = concatenate([LH, secret], axis=3)
        #     HL = concatenate([HL, secret], axis=3)
        #     HH = concatenate([HH, secret], axis=3)
        L = self.conv1(LL)
        H1 = self.conv2(LH, secret)
        H2 = self.conv3(HL, secret)
        H3 = self.conv4(HH, secret)
        return concatenate([LL, L]), [H1, H2, H3]


class DWT_Block_1(Layer):
    """

    """

    def __init__(self, channels, wavename='haar', activation='relu', padding='same', kernel_initializer='he_normal'):
        super(DWT_Block_1, self).__init__()
        self.dwt = DWT_2D(wavename=wavename)
        self.conv1 = Conv2D(channels, 3, padding=padding, activation=activation,
                            kernel_initializer=kernel_initializer)
        self.conv2 = DWT_IDWT_Block(channels, wavename='haar', padding=padding, activation=activation,
                                    kernel_initializer=kernel_initializer)
        self.conv3 = DWT_IDWT_Block(channels, wavename='haar', padding=padding, activation=activation,
                                    kernel_initializer=kernel_initializer)
        self.conv4 = DWT_IDWT_Block(channels, wavename='haar', padding=padding, activation=activation,
                                    kernel_initializer=kernel_initializer)

    def call(self, inputs, secret=None):
        LL, LH, HL, HH = self.dwt(inputs)
        # if secret is not None:
        #     LL = concatenate([LL, secret], axis=3)
        #     LH = concatenate([LH, secret], axis=3)
        #     HL = concatenate([HL, secret], axis=3)
        #     HH = concatenate([HH, secret], axis=3)
        L = self.conv1(LL)
        H1 = self.conv2(LH, secret)
        H2 = self.conv3(HL, secret)
        H3 = self.conv4(HH, secret)
        return concatenate([LL, L]), [H1, H2, H3]


class DWT_Block_2(Layer):
    """

    """

    def __init__(self, channels, wavename='haar', activation='relu', padding='same', kernel_initializer='he_normal'):
        super(DWT_Block_2, self).__init__()
        self.dwt1 = DWT_2D(wavename=wavename)
        self.dwt2 = DWT_2D(wavename=wavename)
        self.conv1 = Conv2D(channels, 3, padding=padding, activation=activation,
                            kernel_initializer=kernel_initializer)

    def call(self, inputs, secret=None):
        LL, LH, HL, HH = self.dwt1(inputs)
        L = self.conv1(LL)
        # if secret is not None:
        #     LL = concatenate([LL, secret], axis=3)
        #     LH = concatenate([LH, secret], axis=3)
        #     HL = concatenate([HL, secret], axis=3)
        #     HH = concatenate([HH, secret], axis=3)
        H = concatenate([LH, HL, HH])
        _, H1, H2, _ = self.dwt2(H)
        H = concatenate([H1, H2])
        return concatenate([LL, L]), H


class DWT_Block_1_simple(Layer):
    """

    """

    def __init__(self, channels, wavename='haar', activation='relu', padding='same', kernel_initializer='he_normal'):
        super(DWT_Block_1_simple, self).__init__()
        self.dwt = DWT_2D_simple(wavename=wavename)
        self.conv1 = Conv2D(channels, 3, padding=padding, activation=activation,
                            kernel_initializer=kernel_initializer)

    def call(self, inputs):
        LL = self.dwt(inputs)
        L = self.conv1(LL)
        return L


class DWT_IDWT_Block_test1(Layer):
    """

    """

    def __init__(self, channels, times=1, wavename='haar', activation='relu', padding='same',
                 kernel_initializer='he_normal'):
        super(DWT_IDWT_Block_test1, self).__init__()
        self.dwt = DWT_2D(wavename=wavename)
        self.idwt = IDWT_2D(wavename=wavename)
        self.times = times
        if times == 1:
            self.conv1 = Conv2D(channels, 3, padding=padding, activation=activation,
                                kernel_initializer=kernel_initializer)
        else:
            self.conv1 = DWT_IDWT_Block_test1(channels, times - 1)
        self.conv2 = Conv2D(channels, 3, padding=padding, activation=activation,
                            kernel_initializer=kernel_initializer)
        self.conv3 = Conv2D(channels, 3, padding=padding, activation=activation,
                            kernel_initializer=kernel_initializer)
        self.conv4 = Conv2D(channels, 3, padding=padding, activation=activation,
                            kernel_initializer=kernel_initializer)

    def call(self, inputs, secret=None):
        LL, LH, HL, HH = self.dwt(inputs)
        if self.times == 1 or secret is None:
            LL_conv = self.conv1(LL)
        else:
            LL_conv = self.conv1(LL, AveragePooling2D((2, 2))(secret))
        LH_conv = self.conv2(concatenate([LH, secret]))
        HL_conv = self.conv3(concatenate([HL, secret]))
        HH_conv = self.conv4(concatenate([HH, secret]))
        return self.idwt(LL_conv, LH_conv, HL_conv, HH_conv)


class DWT_IDWT_Block(Layer):
    """

    """

    def __init__(self, channels, wavename='haar', activation='relu', padding='same', kernel_initializer='he_normal'):
        super(DWT_IDWT_Block, self).__init__()
        self.dwt = DWT_2D(wavename=wavename)
        self.idwt = IDWT_2D(wavename=wavename)
        self.conv1 = Conv2D(channels, 3, padding=padding, activation=activation,
                            kernel_initializer=kernel_initializer)

    def call(self, inputs, secret=None):
        LL, _, _, HH = self.dwt(inputs)
        if secret is not None:
            inputs = concatenate([inputs, secret])
        # output = concatenate([inputs, output])
        conv1 = self.conv1(inputs)
        _, LH, HL, _ = self.dwt(conv1)
        return self.idwt(LL, LH, HL, HH)


class IDWT_Block_1(Layer):
    """

    """

    def __init__(self, channels, wavename='haar', activation='relu', padding='same', kernel_initializer='he_normal'):
        super(IDWT_Block_1, self).__init__()
        self.idwt = IDWT_2D(wavename=wavename)
        self.conv1 = Conv2D(channels, 3, padding=padding, activation=activation,
                            kernel_initializer=kernel_initializer)
        self.conv2 = Conv2D(channels // 2, 3, padding=padding, activation=activation,
                            kernel_initializer=kernel_initializer)

    def call(self, L, H):
        LL = self.conv1(L)
        LH, HL, HH = H
        output = self.idwt(LL, LH, HL, HH)
        return self.conv2(output)


class IDWT_UpSample(Layer):
    """

    """

    def __init__(self, wavename='haar'):
        super(IDWT_UpSample, self).__init__()
        self.idwt = IDWT_2D(wavename=wavename)

    def call(self, inputs):
        z = tf.zeros_like(inputs)
        return self.idwt(inputs, z, z, z)
