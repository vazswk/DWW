import numpy as np
import os
import lpips.lpips_tf as lpips_tf
import tensorflow as tf
import utils
from tensorflow import keras
from tensorflow.python.keras.models import *
from tensorflow.python.keras.layers import *
from dwt_model2 import DWT_IDWT_Block_test1
from dwt_model import *
from stn import spatial_transformer_network as stn_transformer
import tensorflow_addons
import pywt
import tensorflow.compat.v1 as tf
tf.disable_v2_behavior()


class Discriminator(Layer):
    def __init__(self):
        super(Discriminator, self).__init__()
        self.model = Sequential([
            # Conv2D(8, (4, 4), strides=2, activation='relu', padding='same'),
            # Conv2D(16, (4, 4), strides=2, activation='relu', padding='same'),
            # Conv2D(32, (4, 4), strides=2, activation='relu', padding='same'),
            Conv2D(64, (4, 4), strides=2, activation='relu', padding='same'),
            Conv2D(128, (4, 4), strides=2, activation='relu', padding='same'),
            Conv2D(256, (4, 4), strides=2, activation='relu', padding='same'),
            Conv2D(1, (4, 4), activation=None, padding='same')
        ])

    def call(self, image):
        x = image - .5
        x = self.model(x)
        output = tf.reduce_mean(x)
        return output, x



def transform_net(encoded_image, args, global_step):
    ramp_fn = lambda ramp: tf.minimum(tf.cast(global_step, dtype=tf.float32) / ramp, 1.)

    rnd_bri = ramp_fn(args.rnd_bri_ramp) * args.rnd_bri
    rnd_hue = ramp_fn(args.rnd_hue_ramp) * args.rnd_hue
    rnd_brightness = utils.get_rnd_brightness_tf(rnd_bri, rnd_hue, args.batch_size)

    jpeg_quality = 100. - tf.random.uniform([]) * ramp_fn(args.jpeg_quality_ramp) * (100. - args.jpeg_quality)
    jpeg_factor = tf.cond(tf.less(jpeg_quality, 50), lambda: 5000. / jpeg_quality,
                          lambda: 200. - jpeg_quality * 2) / 100. + .0001

    rnd_noise = tf.random.uniform([]) * ramp_fn(args.rnd_noise_ramp) * args.rnd_noise

    contrast_low = 1. - (1. - args.contrast_low) * ramp_fn(args.contrast_ramp)
    contrast_high = 1. + (args.contrast_high - 1.) * ramp_fn(args.contrast_ramp)
    contrast_params = [contrast_low, contrast_high]

    rnd_sat = tf.random.uniform([]) * ramp_fn(args.rnd_sat_ramp) * args.rnd_sat

    f = utils.random_blur_kernel(probs=[.25, .25], N_blur=7,
                                 sigrange_gauss=[1., 3.], sigrange_line=[.25, 1.], wmin_line=3)
    encoded_image = tf.nn.conv2d(encoded_image, f, [1, 1, 1, 1], padding='SAME')

    noise = tf.random_normal(shape=tf.shape(encoded_image), mean=0.0, stddev=rnd_noise, dtype=tf.float32)
    encoded_image = encoded_image + noise
    encoded_image = tf.clip_by_value(encoded_image, 0, 1)

    contrast_scale = tf.random_uniform(shape=[tf.shape(encoded_image)[0]], minval=contrast_params[0],
                                       maxval=contrast_params[1])
    contrast_scale = tf.reshape(contrast_scale, shape=[tf.shape(encoded_image)[0], 1, 1, 1])

    encoded_image = encoded_image * contrast_scale

    encoded_image = encoded_image + rnd_brightness
    encoded_image = tf.clip_by_value(encoded_image, 0, 1)

    encoded_image_lum = tf.expand_dims(tf.reduce_sum(encoded_image * tf.constant([.3, .6, .1]), axis=3), 3)
    encoded_image = (1 - rnd_sat) * encoded_image + rnd_sat * encoded_image_lum

    encoded_image = tf.reshape(encoded_image, [-1, 400, 400, 3])
    if not args.no_jpeg:
        encoded_image = utils.jpeg_compress_decompress(encoded_image, rounding=utils.round_only_at_0,
                                                       factor=jpeg_factor, downsample_c=True)

    summaries = [tf.summary.scalar('transformer/rnd_bri', rnd_bri),
                 tf.summary.scalar('transformer/rnd_sat', rnd_sat),
                 tf.summary.scalar('transformer/rnd_hue', rnd_hue),
                 tf.summary.scalar('transformer/rnd_noise', rnd_noise),
                 tf.summary.scalar('transformer/contrast_low', contrast_low),
                 tf.summary.scalar('transformer/contrast_high', contrast_high),
                 tf.summary.scalar('transformer/jpeg_quality', jpeg_quality)]

    return encoded_image, summaries


def transform_net_1(encoded_image, args, global_step):
    ramp_fn = lambda ramp: tf.minimum(tf.cast(global_step, dtype=tf.float32) / ramp, 1.)

    def true_fn():
        m_noise = utils.tf_Moire_Distortion(encoded_image)
        distorted = encoded_image * utils.tf_Light_Distortion(encoded_image) * 0.85 + m_noise * 0.15
        distorted = tf.clip_by_value(distorted, 0, 1)
        return distorted

    def false_fn():
        return encoded_image

    processed_image = tf.cond(global_step >= 2000, true_fn, false_fn)

    rnd_noise = tf.random.uniform([]) * ramp_fn(args.rnd_noise_ramp) * args.rnd_noise
    noise = tf.random.normal(shape=tf.shape(processed_image), mean=0.0, stddev=rnd_noise, dtype=tf.float32)
    processed_image += noise
    processed_image = tf.clip_by_value(processed_image, 0, 1)
    processed_image = tf.reshape(processed_image, [-1, 400, 400, 3])

    summaries = [
                 tf.summary.scalar('transformer/rnd_noise', rnd_noise)]

    return processed_image, summaries



def get_secret_acc(secret_true, secret_pred):
    with tf.variable_scope("acc"):
        secret_pred = tf.round(tf.sigmoid(secret_pred))
        correct_pred = tf.cast(tf.shape(secret_pred)[1], tf.int64) - tf.count_nonzero(secret_pred - secret_true, axis=1)

        str_acc = 1.0 - tf.count_nonzero(correct_pred - tf.cast(
            tf.shape(secret_pred)[1], dtype=tf.int64)) / tf.size(correct_pred, out_type=tf.int64)

        bit_acc = tf.reduce_sum(correct_pred) / tf.size(secret_pred, out_type=tf.int64)
        return bit_acc, str_acc


def build_model(encoder,
                decoder,
                discriminator,
                secret_input,
                image_input,
                edge_mask,
                mask_scale,
                l2_edge_gain,
                borders,
                secret_size,
                M,
                loss_scales,
                yuv_scales,
                args,
                global_step):
    input_warped = tensorflow_addons.image.transform(image_input, M[:, 1, :], interpolation='BILINEAR')
    mask_warped = tensorflow_addons.image.transform(tf.ones_like(input_warped), M[:, 1, :], interpolation='BILINEAR')
    input_warped += (1 - mask_warped) * image_input

    residual_warped = encoder((secret_input, input_warped))
    encoded_warped = residual_warped + input_warped
    residual = tensorflow_addons.image.transform(residual_warped, M[:, 0, :], interpolation='BILINEAR')

    if borders == 'no_edge':
        encoded_image = image_input + residual
    elif borders == 'black':
        encoded_image = residual_warped + input_warped
        encoded_image = tensorflow_addons.image.transform(encoded_image, M[:, 0, :], interpolation='BILINEAR')
        input_unwarped = tensorflow_addons.image.transform(input_warped, M[:, 0, :], interpolation='BILINEAR')
    elif borders.startswith('random'):
        mask = tensorflow_addons.image.transform(tf.ones_like(residual), M[:, 0, :], interpolation='BILINEAR')
        encoded_image = residual_warped + input_warped
        encoded_image = tensorflow_addons.image.transform(encoded_image, M[:, 0, :], interpolation='BILINEAR')
        input_unwarped = tensorflow_addons.image.transform(input_warped, M[:, 0, :], interpolation='BILINEAR')
        ch = 3 if borders.endswith('rgb') else 1
        encoded_image += (1 - mask) * tf.ones_like(residual) * tf.random.uniform([ch])
    elif borders == 'white':
        mask = tensorflow_addons.image.transform(tf.ones_like(residual), M[:, 0, :], interpolation='BILINEAR')
        encoded_image = residual_warped + input_warped
        encoded_image = tensorflow_addons.image.transform(encoded_image, M[:, 0, :], interpolation='BILINEAR')
        input_unwarped = tensorflow_addons.image.transform(input_warped, M[:, 0, :], interpolation='BILINEAR')
        encoded_image += (1 - mask) * tf.ones_like(residual)
    elif borders == 'image':
        mask = tensorflow_addons.image.transform(tf.ones_like(residual), M[:, 0, :], interpolation='BILINEAR')
        encoded_image = residual_warped + input_warped
        encoded_image = tensorflow_addons.image.transform(encoded_image, M[:, 0, :], interpolation='BILINEAR')
        encoded_image += (1 - mask) * tf.manip.roll(image_input, shift=1, axis=0)

    if borders == 'no_edge':
        D_output_real, _ = discriminator(image_input)
        D_output_fake, D_heatmap = discriminator(encoded_image)
    else:
        D_output_real, _ = discriminator(input_warped)
        D_output_fake, D_heatmap = discriminator(encoded_warped)

    if borders == 'no_edge':
        PSNR = tf.image.psnr(encoded_image, image_input, max_val=1.0)
    else:
        PSNR = tf.image.psnr(encoded_warped, input_warped, max_val=1.0)
    PSNR = tf.reduce_mean(PSNR)

    transformed_image, transform_summaries = transform_net(encoded_image, args, global_step)
    # transformed_image, transform_summaries = transform_net_1(encoded_image, args, global_step)

    decoded_secret = decoder(transformed_image)

    bit_acc, str_acc = get_secret_acc(secret_input, decoded_secret)

    lpips_loss_op = tf.reduce_mean(lpips_tf.lpips(image_input, encoded_image))
    secret_loss_op = tf.losses.sigmoid_cross_entropy(secret_input, decoded_secret)


    residual_dtf = test_7(residual)
    # loss_test = loss_test * edge_mask
    loss_test = tf.reduce_mean(tf.square(residual_dtf))

    ssim = tf.image.ssim_multiscale(image_input, encoded_image, max_val=1.0)
    ssim = tf.reduce_mean(ssim)

    encoded_image_yuv = tf.image.rgb_to_yuv(encoded_image)
    image_input_yuv = tf.image.rgb_to_yuv(image_input)
    im_diff = encoded_image_yuv - image_input_yuv
    im_diff = im_diff + mask_scale * im_diff * edge_mask
    yuv_loss_op = tf.reduce_mean(tf.square(im_diff), axis=[0, 1, 2])
    image_loss_op = tf.tensordot(yuv_loss_op, yuv_scales, axes=1)

    D_loss = D_output_real - D_output_fake
    G_loss = D_output_fake

    loss_op = loss_scales[0] * image_loss_op + loss_scales[1] * lpips_loss_op + loss_scales[2] * secret_loss_op + \
              loss_scales[4] * loss_test
    if not args.no_gan:
        loss_op += loss_scales[3] * G_loss

    summary_op = tf.summary.merge([
                                      tf.summary.scalar('bit_acc', bit_acc, family='train'),
                                      tf.summary.scalar('str_acc', str_acc, family='train'),
                                      tf.summary.scalar('loss', loss_op, family='train'),
                                      tf.summary.scalar('image_loss', image_loss_op, family='train'),
                                      tf.summary.scalar('lpip_loss', lpips_loss_op, family='train'),
                                      tf.summary.scalar('G_loss', G_loss, family='train'),
                                      tf.summary.scalar('secret_loss', secret_loss_op, family='train'),
                                      tf.summary.scalar('dis_loss', D_loss, family='train'),
                                      tf.summary.scalar('PSNR', PSNR, family='train'),
                                      tf.summary.scalar('ssim', ssim, family='train'),
                                      tf.summary.scalar('test_loss_1', loss_test, family='train'),
                                      tf.summary.scalar('Y_loss', yuv_loss_op[0], family='color_loss'),
                                      tf.summary.scalar('U_loss', yuv_loss_op[1], family='color_loss'),
                                      tf.summary.scalar('V_loss', yuv_loss_op[2], family='color_loss'),
                                      tf.summary.scalar('mask_scale', mask_scale, family='loss_scales'),
                                  ] + transform_summaries)

    image_summary_op = tf.summary.merge([
        image_to_summary(image_input, 'image_input', family='input'),
        image_to_summary(input_warped, 'image_warped', family='input'),
        image_to_summary(encoded_warped, 'encoded_warped', family='encoded'),
        image_to_summary(residual_warped + .5, 'residual', family='encoded'),
        image_to_summary(residual_dtf + .5, 'residual', family='encoded'),
        image_to_summary(encoded_image, 'encoded_image', family='encoded'),
        image_to_summary(transformed_image, 'transformed_image', family='transformed'),
        # image_to_summary(smooth, 'smooth', family='transformed'),
        image_to_summary(D_heatmap, 'discriminator', family='losses'),
        image_to_summary(edge_mask, 'edge_mask', family='input'),
    ])

    return loss_op, secret_loss_op, D_loss, summary_op, image_summary_op, bit_acc


def image_to_summary(image, name, family='train'):
    image = tf.clip_by_value(image, 0, 1)
    image = tf.cast(image * 255, dtype=tf.uint8)
    summary = tf.summary.image(name, image, max_outputs=1, family=family)
    return summary


def prepare_deployment_hiding_graph(encoder, secret_input, image_input):
    residual = encoder((secret_input, image_input))
    encoded_image = residual + image_input
    encoded_image = tf.clip_by_value(encoded_image, 0, 1)

    return encoded_image, residual


def prepare_deployment_reveal_graph(decoder, image_input):
    decoded_secret = decoder(image_input)

    return tf.round(tf.sigmoid(decoded_secret))


def gird_filter(image_input, grid_size=[8, 8], padding="REFLECT"):
    _, H, W, C = image_input.shape
    enlarge_h = int(H) // (grid_size[0] * 2)
    enlarge_w = int(W) // (grid_size[1] * 2)
    pad_bottom = int(H) - enlarge_h * grid_size[0] * 2
    pad_right = int(W) - enlarge_w * grid_size[1] * 2
    paddings = [[0, pad_bottom], [0, pad_right], [0, 0], [0, 0]]
    paddings_img = [[0, 0], [0, grid_size[0]], [0, grid_size[1]], [0, 0]]
    kernel = np.array([[-1., 1.], [1., -1.]])
    kernel = tf.cast(np.kron(np.ones([enlarge_h, enlarge_w]), kernel), dtype=tf.float32)
    kernel = tf.expand_dims(tf.expand_dims(kernel, axis=-1) * tf.ones([1, 1, int(C)]), axis=0)
    kernel = tf.transpose(UpSampling2D(size=(grid_size[0], grid_size[1]))(kernel), [1, 2, 3, 0])
    kernel = tf.pad(kernel, paddings, mode=padding, constant_values=0)
    img_pad = tf.pad(image_input, paddings_img, mode=padding, constant_values=0)
    image_output = tf.nn.depthwise_conv2d(img_pad, filter=kernel, strides=[1, 1, 1, 1], padding="VALID")
    return tf.abs(image_output)

def smooth_loss(y_true, y_pred,residual_warped):
    mse = tf.reduce_mean(tf.square(y_true - y_pred))

    y_true_grad_x, y_true_grad_y = tf.image.image_gradients(y_true)
    y_pred_grad_x, y_pred_grad_y = tf.image.image_gradients(y_pred)

    grad_smooth_loss = tf.reduce_mean(tf.square(y_true_grad_x - y_pred_grad_x) + tf.square(y_true_grad_y - y_pred_grad_y))

    combined_loss = mse + grad_smooth_loss + test_5(residual_warped)

    return combined_loss


def noise0_1(x):
    # noise = tf.ones_like(image,optimize=False)
    # print(image.shape[0])
    size = [int(x) for x in x.shape[1:]]
    noise = np.random.randint(-1, 2, size) / 255.
    return np.expand_dims(noise, 0)


def test_7(image_input, sigma=20, beta=18):
    # image = image_input
    # tf_min = tf.reduce_min(image_input)
    # tf_max = tf.reduce_max(image_input)
    W_F_np = utils.compute_weight_matrix(400, 400, sigma, beta)
    # image = utils.DFT_standardization(image_input)
    channel_image1 = image_input[:, :, :, 0]
    # channel_image1 = utils.DFT_standardization(channel_image1)
    spectrum = utils.dft_2d(channel_image1)
    spectrum = tf.signal.fftshift(spectrum)
    enhanced_spectrum1 = utils.enhance_frequency(spectrum, W_F_np)
    enhanced_spectrum1 = tf.signal.ifftshift(enhanced_spectrum1)
    enhanced_image1 = utils.idft_2d(enhanced_spectrum1)
    enhanced_image1 = tf.cast(enhanced_image1, dtype=tf.float32)

    channel_image2 = image_input[:, :, :, 1]
    # channel_image2 = utils.DFT_standardization(channel_image2)
    spectrum = utils.dft_2d(channel_image2)
    spectrum = tf.signal.fftshift(spectrum)
    enhanced_spectrum2 = utils.enhance_frequency(spectrum, W_F_np)
    # IDFT
    enhanced_spectrum2 = tf.signal.ifftshift(enhanced_spectrum2)
    enhanced_image2 = utils.idft_2d(enhanced_spectrum2)
    enhanced_image2 = tf.cast(enhanced_image2, dtype=tf.float32)

    channel_image3 = image_input[:, :, :, 2]
    # channel_image3 = utils.DFT_standardization(channel_image3)
    spectrum = utils.dft_2d(channel_image3)
    spectrum = tf.signal.fftshift(spectrum)
    enhanced_spectrum3 = utils.enhance_frequency(spectrum, W_F_np)
    # IDFT
    enhanced_spectrum3 = tf.signal.ifftshift(enhanced_spectrum3)
    enhanced_image3 = utils.idft_2d(enhanced_spectrum3)
    enhanced_image3 = tf.cast(enhanced_image3, dtype=tf.float32)

    image = tf.stack([enhanced_image1, enhanced_image2, enhanced_image3], 3)
    # image = tf.clip_by_value(image,tf_min,tf_max)
    loss = image - image_input
    return loss
