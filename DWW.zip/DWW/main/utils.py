import cv2
import itertools
import numpy as np
import random
import tensorflow as tf
import tensorflow.compat.v1 as tf
import math
tf.disable_v2_behavior()

def get_edge(imge, size):
    imge = cv2.resize(imge, size)
    canny = cv2.Canny(imge, 50, 150, )

    ret, binary = cv2.threshold(canny, 0, 255, cv2.THRESH_BINARY | cv2.THRESH_OTSU)

    kernel_2 = cv2.getStructuringElement(cv2.MORPH_RECT, (2, 2))
    dilate_2 = cv2.dilate(binary, kernel=kernel_2)
    edge_2 = dilate_2
    edge_2 = 0.9 * edge_2

    kernel_3 = cv2.getStructuringElement(cv2.MORPH_RECT, (4, 4))
    dilate_3 = cv2.dilate(binary, kernel=kernel_3)
    edge_3 = dilate_3
    edge_3 = 0.8 * edge_3

    kernel_4 = cv2.getStructuringElement(cv2.MORPH_RECT, (6, 6))
    dilate_4 = cv2.dilate(binary, kernel=kernel_4)
    edge_4 = dilate_4
    edge_4 = 0.7 * edge_4

    kernel_5 = cv2.getStructuringElement(cv2.MORPH_RECT, (8, 8))
    dilate_5 = cv2.dilate(binary, kernel=kernel_5)
    edge_5 = dilate_5
    edge_5 = 0.6 * edge_5

    kernel_6 = cv2.getStructuringElement(cv2.MORPH_RECT, (10, 10))
    dilate_6 = cv2.dilate(binary, kernel=kernel_6)
    edge_6 = dilate_6
    edge_6 = 0.5 * edge_6

    kernel_7 = cv2.getStructuringElement(cv2.MORPH_RECT, (12, 12))
    dilate_7 = cv2.dilate(binary, kernel=kernel_7)
    edge_7 = dilate_7
    edge_7 = 0.4 * edge_7

    kernel_8 = cv2.getStructuringElement(cv2.MORPH_RECT, (14, 14))
    dilate_8 = cv2.dilate(binary, kernel=kernel_8)
    edge_8 = dilate_8
    edge_8 = 0.3 * edge_8

    kernel_9 = cv2.getStructuringElement(cv2.MORPH_RECT, (16, 16))
    dilate_9 = cv2.dilate(binary, kernel=kernel_9)
    edge_9 = dilate_9
    edge_9 = 0.2 * edge_9

    edge = edge_2 + edge_3 + edge_4 + edge_5 + edge_6 + edge_7 + edge_8 + edge_9

    edge = np.array(edge, dtype=np.float32) / 1120.

    return edge


# def get_edge(imge,size):
#     imge=cv2.resize(imge,size)
#     canny = cv2.Canny(imge, 50, 150, )
#     # gray = cv2.cvtColor(imge, cv2.COLOR_BGR2GRAY)
#     ret, binary = cv2.threshold(canny, 0, 255, cv2.THRESH_BINARY | cv2.THRESH_OTSU)
#     kernel_2 = cv2.getStructuringElement(cv2.MORPH_RECT, (2, 2))
#     dilate_2 = cv2.dilate(binary, kernel=kernel_2)
#     erode_2 = cv2.erode(binary, kernel=kernel_2)
#     edge_2 = dilate_2 - erode_2
#     edge_2 = 0.8 * edge_2

#     kernel_3 = cv2.getStructuringElement(cv2.MORPH_RECT, (4, 4))
#     dilate_3 = cv2.dilate(binary, kernel=kernel_3)
#     erode_3 = cv2.erode(binary, kernel=kernel_3)
#     edge_3 = dilate_3 - erode_3
#     edge_3 = 0.6 * edge_3

#     kernel_4 = cv2.getStructuringElement(cv2.MORPH_RECT, (6, 6))
#     dilate_4 = cv2.dilate(binary, kernel=kernel_4)
#     erode_4 = cv2.erode(binary, kernel=kernel_4)
#     edge_4 = dilate_4 - erode_4
#     edge_4 = 0.4 * edge_4

#     kernel_5 = cv2.getStructuringElement(cv2.MORPH_RECT, (8, 8))
#     dilate_5 = cv2.dilate(binary, kernel=kernel_5)
#     erode_5 = cv2.erode(binary, kernel=kernel_5)
#     edge_5 = dilate_5 - erode_5
#     edge_5 = 0.2 * edge_5

#     edge = edge_2 + edge_3 + edge_4 + edge_5
#     edge = np.array(edge, dtype=np.float32) / 510.
#     return edge


def gaussian2D(shape, sigma=1):
    '''
    '''
    m, n = [(ss - 1.) / 2. for ss in shape]
    y, x = np.ogrid[-m:m + 1, -n:n + 1]
    h = np.exp(-(x * x + y * y) / (2 * sigma * sigma))  ## 将高斯核中小于一个非常小的阈值的数值置为0，以避免在计算中引入不必要的噪音。
    return h


def gaussian_radius(det_size, min_overlap=0.7):
    height, width = det_size
    a1 = 1
    b1 = (height + width)
    c1 = width * height * (1 - min_overlap) / (1 + min_overlap)
    sq1 = np.sqrt(b1 ** 2 - 4 * a1 * c1)
    r1 = (b1 + sq1) / 2

    a2 = 4
    b2 = 2 * (height + width)
    c2 = (1 - min_overlap) * width * height
    sq2 = np.sqrt(b2 ** 2 - 4 * a2 * c2)
    r2 = (b2 + sq2) / 2

    a3 = 4 * min_overlap
    b3 = -2 * min_overlap * (height + width)
    c3 = (min_overlap - 1) * width * height
    sq3 = np.sqrt(b3 ** 2 - 4 * a3 * c3)
    r3 = (b3 + sq3) / 2
    return min(r1, r2, r3)

def draw_umich_gaussian(heatmap, center, radius, k=1):
    diameter = 2 * radius + 1
    gaussian = gaussian2D((diameter, diameter), sigma=diameter / 6)

    x, y = int(center[0]), int(center[1])

    height, width = heatmap.shape[0:2]

    left, right = min(x, radius), min(width - x, radius + 1)
    top, bottom = min(y, radius), min(height - y, radius + 1)

    masked_heatmap = heatmap[y - top:y + bottom, x - left:x + right]
    masked_gaussian = gaussian[radius - top:radius + bottom, radius - left:radius + right]

    if min(masked_gaussian.shape) > 0 and min(masked_heatmap.shape) > 0:  # TODO debug
        np.maximum(masked_heatmap, masked_gaussian * k, out=masked_heatmap)
    return heatmap


def random_blur_kernel(probs, N_blur, sigrange_gauss, sigrange_line, wmin_line):
    N = N_blur
    coords = tf.cast(tf.stack(tf.meshgrid(tf.range(N_blur), tf.range(N_blur), indexing='ij'), -1),
                     dtype=tf.float32) - (.5 * (N - 1))
    # coords = tf.to_float(coords)
    manhat = tf.reduce_sum(tf.abs(coords), -1)


    vals_nothing = tf.cast(manhat < .5, dtype=tf.float32)


    sig_gauss = tf.random.uniform([], sigrange_gauss[0], sigrange_gauss[1])
    vals_gauss = tf.exp(-tf.reduce_sum(coords ** 2, -1) / 2. / sig_gauss ** 2)

    # line

    theta = tf.random.uniform([], 0, 2. * np.pi)
    v = tf.convert_to_tensor([tf.cos(theta), tf.sin(theta)])
    dists = tf.reduce_sum(coords * v, -1)
    sig_line = tf.random.uniform([], sigrange_line[0], sigrange_line[1])
    w_line = tf.random.uniform([], wmin_line, .5 * (N - 1) + .1)

    vals_line = tf.exp(-dists ** 2 / 2. / sig_line ** 2) * tf.cast(manhat < w_line, dtype=tf.float32)

    t = tf.random.uniform([])
    vals = vals_nothing
    vals = tf.cond(t < probs[0] + probs[1], lambda: vals_line, lambda: vals)
    vals = tf.cond(t < probs[0], lambda: vals_gauss, lambda: vals)

    v = vals / tf.reduce_sum(vals)
    z = tf.zeros_like(v)
    f = tf.reshape(tf.stack([v, z, z, z, v, z, z, z, v], -1), [N, N, 3, 3])

    return f


def get_rand_transform_matrix(image_size, d, batch_size):
    Ms = np.zeros((batch_size, 2, 8))

    for i in range(batch_size):
        tl_x = random.uniform(-d, d)  # Top left corner, top
        tl_y = random.uniform(-d, d)  # Top left corner, left
        bl_x = random.uniform(-d, d)  # Bot left corner, bot
        bl_y = random.uniform(-d, d)  # Bot left corner, left
        tr_x = random.uniform(-d, d)  # Top right corner, top
        tr_y = random.uniform(-d, d)  # Top right corner, right
        br_x = random.uniform(-d, d)  # Bot right corner, bot
        br_y = random.uniform(-d, d)  # Bot right corner, right

        rect = np.array([
            [tl_x, tl_y],
            [tr_x + image_size, tr_y],
            [br_x + image_size, br_y + image_size],
            [bl_x, bl_y + image_size]], dtype="float32")

        dst = np.array([
            [0, 0],
            [image_size, 0],
            [image_size, image_size],
            [0, image_size]], dtype="float32")

        M = cv2.getPerspectiveTransform(rect, dst)
        M_inv = np.linalg.inv(M)
        Ms[i, 0, :] = M_inv.flatten()[:8]
        Ms[i, 1, :] = M.flatten()[:8]
    return Ms


def get_rnd_brightness_tf(rnd_bri, rnd_hue, batch_size):
    rnd_hue = tf.random.uniform((batch_size, 1, 1, 3), -rnd_hue, rnd_hue)
    rnd_brightness = tf.random.uniform((batch_size, 1, 1, 1), -rnd_bri, rnd_bri)
    return rnd_hue + rnd_brightness


## Differentiable JPEG, Source - https://github.com/rshin/differentiable-jpeg/blob/master/jpeg-tensorflow.ipynb

# 1. RGB -> YCbCr
# https://en.wikipedia.org/wiki/YCbCr
def rgb_to_ycbcr(image):
    matrix = np.array(
        [[65.481, 128.553, 24.966], [-37.797, -74.203, 112.],
         [112., -93.786, -18.214]],
        dtype=np.float32).T / 255
    shift = [16., 128., 128.]

    result = tf.tensordot(image, matrix, axes=1) + shift
    result.set_shape(image.shape.as_list())
    return result


def rgb_to_ycbcr_jpeg(image):
    matrix = np.array(
        [[0.299, 0.587, 0.114], [-0.168736, -0.331264, 0.5],
         [0.5, -0.418688, -0.081312]],
        dtype=np.float32).T
    shift = [0., 128., 128.]

    result = tf.tensordot(image, matrix, axes=1) + shift
    result.set_shape(image.shape.as_list())
    return result


# 2. Chroma subsampling
def downsampling_420(image):
    # input: batch x height x width x 3
    # output: tuple of length 3
    #   y:  batch x height x width
    #   cb: batch x height/2 x width/2
    #   cr: batch x height/2 x width/2
    y, cb, cr = tf.split(image, 3, axis=3)
    cb = tf.nn.avg_pool(
        cb, ksize=[1, 2, 2, 1], strides=[1, 2, 2, 1], padding='SAME')
    cr = tf.nn.avg_pool(
        cr, ksize=[1, 2, 2, 1], strides=[1, 2, 2, 1], padding='SAME')
    return (tf.squeeze(
        y, axis=-1), tf.squeeze(
        cb, axis=-1), tf.squeeze(
        cr, axis=-1))


# 3. Block splitting
# From https://stackoverflow.com/questions/41564321/split-image-tensor-into-small-patches
def image_to_patches(image):
    # input: batch x h x w
    # output: batch x h*w/64 x h x w
    k = 8
    height, width = image.shape.as_list()[1:3]
    batch_size = tf.shape(image)[0]
    image_reshaped = tf.reshape(image, [batch_size, height // k, k, -1, k])
    image_transposed = tf.transpose(image_reshaped, [0, 1, 3, 2, 4])
    return tf.reshape(image_transposed, [batch_size, -1, k, k])


def dct_8x8_ref(image):
    image = image - 128
    result = np.zeros((8, 8), dtype=np.float32)
    for u, v in itertools.product(range(8), range(8)):
        value = 0
        for x, y in itertools.product(range(8), range(8)):
            value += image[x, y] * np.cos((2 * x + 1) * u * np.pi / 16) * np.cos(
                (2 * y + 1) * v * np.pi / 16)
        result[u, v] = value
    alpha = np.array([1. / np.sqrt(2)] + [1] * 7)
    scale = np.outer(alpha, alpha) * 0.25
    return result * scale


def dct_8x8(image):
    image = image - 128
    tensor = np.zeros((8, 8, 8, 8), dtype=np.float32)
    for x, y, u, v in itertools.product(range(8), repeat=4):
        tensor[x, y, u, v] = np.cos((2 * x + 1) * u * np.pi / 16) * np.cos(
            (2 * y + 1) * v * np.pi / 16)
    alpha = np.array([1. / np.sqrt(2)] + [1] * 7)
    scale = np.outer(alpha, alpha) * 0.25
    result = scale * tf.tensordot(image, tensor, axes=2)
    result.set_shape(image.shape.as_list())
    return result


y_table = np.array(
    [[16, 11, 10, 16, 24, 40, 51, 61], [12, 12, 14, 19, 26, 58, 60,
                                        55], [14, 13, 16, 24, 40, 57, 69, 56],
     [14, 17, 22, 29, 51, 87, 80, 62], [18, 22, 37, 56, 68, 109, 103,
                                        77], [24, 35, 55, 64, 81, 104, 113, 92],
     [49, 64, 78, 87, 103, 121, 120, 101], [72, 92, 95, 98, 112, 100, 103, 99]],
    dtype=np.float32).T
c_table = np.empty((8, 8), dtype=np.float32)
c_table.fill(99)
c_table[:4, :4] = np.array([[17, 18, 24, 47], [18, 21, 26, 66],
                            [24, 26, 56, 99], [47, 66, 99, 99]]).T


def y_quantize(image, rounding, factor=1):
    image = image / (y_table * factor)
    image = rounding(image)
    return image


def c_quantize(image, rounding, factor=1):
    image = image / (c_table * factor)
    image = rounding(image)
    return image


# -5. Dequantization
def y_dequantize(image, factor=1):
    return image * (y_table * factor)


def c_dequantize(image, factor=1):
    return image * (c_table * factor)


# -4. Inverse DCT
def idct_8x8_ref(image):
    alpha = np.array([1. / np.sqrt(2)] + [1] * 7)
    alpha = np.outer(alpha, alpha)
    image = image * alpha

    result = np.zeros((8, 8), dtype=np.float32)
    for u, v in itertools.product(range(8), range(8)):
        value = 0
        for x, y in itertools.product(range(8), range(8)):
            value += image[x, y] * np.cos((2 * u + 1) * x * np.pi / 16) * np.cos(
                (2 * v + 1) * y * np.pi / 16)
        result[u, v] = value
    return result * 0.25 + 128


def idct_8x8(image):
    alpha = np.array([1. / np.sqrt(2)] + [1] * 7)
    alpha = np.outer(alpha, alpha)
    image = image * alpha

    tensor = np.zeros((8, 8, 8, 8), dtype=np.float32)
    for x, y, u, v in itertools.product(range(8), repeat=4):
        tensor[x, y, u, v] = np.cos((2 * u + 1) * x * np.pi / 16) * np.cos(
            (2 * v + 1) * y * np.pi / 16)
    result = 0.25 * tf.tensordot(image, tensor, axes=2) + 128
    result.set_shape(image.shape.as_list())
    return result


# -3. Block joining
def patches_to_image(patches, height, width):
    # input: batch x h*w/64 x h x w
    # output: batch x h x w
    k = 8
    batch_size = tf.shape(patches)[0]
    image_reshaped = tf.reshape(patches,
                                [batch_size, height // k, width // k, k, k])
    image_transposed = tf.transpose(image_reshaped, [0, 1, 3, 2, 4])
    return tf.reshape(image_transposed, [batch_size, height, width])


# -2. Chroma upsampling
def upsampling_420(y, cb, cr):
    # input:
    #   y:  batch x height x width
    #   cb: batch x height/2 x width/2
    #   cr: batch x height/2 x width/2
    # output:
    #   image: batch x height x width x 3
    def repeat(x, k=2):
        height, width = x.shape.as_list()[1:3]
        x = tf.expand_dims(x, -1)
        x = tf.tile(x, [1, 1, k, k])
        x = tf.reshape(x, [-1, height * k, width * k])
        return x

    cb = repeat(cb)
    cr = repeat(cr)
    return tf.stack((y, cb, cr), axis=-1)


# -1. YCbCr -> RGB
def ycbcr_to_rgb(image):
    matrix = np.array(
        [[298.082, 0, 408.583], [298.082, -100.291, -208.120],
         [298.082, 516.412, 0]],
        dtype=np.float32).T / 256
    shift = [-222.921, 135.576, -276.836]

    result = tf.tensordot(image, matrix, axes=1) + shift
    result.set_shape(image.shape.as_list())
    return result


def ycbcr_to_rgb_jpeg(image):
    matrix = np.array(
        [[1., 0., 1.402], [1, -0.344136, -0.714136], [1, 1.772, 0]],
        dtype=np.float32).T
    shift = [0, -128, -128]

    result = tf.tensordot(image + shift, matrix, axes=1)
    result.set_shape(image.shape.as_list())
    return result


def diff_round(x):
    return tf.round(x) + (x - tf.round(x)) ** 3


def round_only_at_0(x):
    cond = tf.cast(tf.abs(x) < 0.5, tf.float32)
    return cond * (x ** 3) + (1 - cond) * x


def jpeg_compress_decompress(image,
                             downsample_c=True,
                             rounding=diff_round,
                             factor=1):
    image *= 255
    height, width = image.shape.as_list()[1:3]
    orig_height, orig_width = height, width
    if height % 16 != 0 or width % 16 != 0:
        # Round up to next multiple of 16
        height = ((height - 1) // 16 + 1) * 16
        width = ((width - 1) // 16 + 1) * 16

        vpad = height - orig_height
        wpad = width - orig_width
        top = vpad // 2
        bottom = vpad - top
        left = wpad // 2
        right = wpad - left

        # image = tf.pad(image, [[0, 0], [top, bottom], [left, right], [0, 0]], 'SYMMETRIC')
        image = tf.pad(image, [[0, 0], [0, vpad], [0, wpad], [0, 0]], 'SYMMETRIC')

    # "Compression"
    image = rgb_to_ycbcr_jpeg(image)
    if downsample_c:
        y, cb, cr = downsampling_420(image)
    else:
        y, cb, cr = tf.split(image, 3, axis=3)
    components = {'y': y, 'cb': cb, 'cr': cr}
    for k in components.keys():
        comp = components[k]
        comp = image_to_patches(comp)
        comp = dct_8x8(comp)
        comp = c_quantize(comp, rounding,
                          factor) if k in ('cb', 'cr') else y_quantize(
            comp, rounding, factor)
        components[k] = comp

    # "Decompression"
    for k in components.keys():
        comp = components[k]
        comp = c_dequantize(comp, factor) if k in ('cb', 'cr') else y_dequantize(
            comp, factor)
        comp = idct_8x8(comp)
        if k in ('cb', 'cr'):
            if downsample_c:
                comp = patches_to_image(comp, int(height / 2), int(width / 2))
            else:
                comp = patches_to_image(comp, height, width)
        else:
            comp = patches_to_image(comp, height, width)
        components[k] = comp

    y, cb, cr = components['y'], components['cb'], components['cr']
    if downsample_c:
        image = upsampling_420(y, cb, cr)
    else:
        image = tf.stack((y, cb, cr), axis=-1)
    image = ycbcr_to_rgb_jpeg(image)

    # Crop to original size
    if orig_height != height or orig_width != width:
        # image = image[:, top:-bottom, left:-right]
        image = image[:, :-vpad, :-wpad]

    # Hack: RGB -> YUV -> RGB sometimes results in incorrect values
    #    min_value = tf.minimum(tf.reduce_min(image), 0.)
    #    max_value = tf.maximum(tf.reduce_max(image), 255.)
    #    value_range = max_value - min_value
    #    image = 255 * (image - min_value) / value_range
    image = tf.minimum(255., tf.maximum(0., image))
    image /= 255

    return image


def quality_to_factor(quality):
    if quality < 50:
        quality = 5000. / quality
    else:
        quality = 200. - quality * 2
    return quality / 100.


# Define the Moire pattern generation function in TensorFlow
@tf.function
def tf_MoireGen(p_size, theta, center_x, center_y):
    i_idx, j_idx = tf.meshgrid(tf.range(p_size, dtype=tf.float32),
                               tf.range(p_size, dtype=tf.float32),
                               indexing='ij')
    z1 = 0.5 + 0.5 * tf.math.cos(2 * math.pi * tf.sqrt((i_idx + 1 - center_x)**2 + (j_idx + 1 - center_y)**2))
    z2 = 0.5 + 0.5 * tf.math.cos(tf.math.cos(theta / 180 * math.pi) * (j_idx + 1) + tf.math.sin(theta / 180 * math.pi) * (i_idx + 1))
    z = tf.reduce_min(tf.stack([z1, z2], axis=2), axis=2)
    M = (z + 1) / 2
    return M

# Define the function to apply the Moire pattern as distortion to an image
@tf.function
def tf_Moire_Distortion(embed_image):
    shape = tf.shape(embed_image)
    channels = shape[-1]
    moire_patterns = tf.TensorArray(dtype=tf.float32, size=channels)

    # Generate a Moire pattern for each channel
    for i in tf.range(channels):
        theta = tf.random.uniform([], minval=0, maxval=180)
        center_x = tf.random.uniform([], minval=0, maxval=tf.cast(shape[1], tf.float32))
        center_y = tf.random.uniform([], minval=0, maxval=tf.cast(shape[2], tf.float32))
        M = tf_MoireGen(shape[1], theta, center_x, center_y)
        moire_patterns = moire_patterns.write(i, M)

    # Stack all the Moire patterns and expand to match the input image shape
    Z = moire_patterns.stack()
    Z = tf.transpose(Z, [1, 2, 0])  # Transpose to match image shape
    Z = tf.expand_dims(Z, 0)  # Add batch dimension
    Z = tf.tile(Z, [shape[0], 1, 1, 1])  # Tile to match the batch size

    return Z

@tf.function
def tf_Light_Distortion(embed_image):
    shape = tf.shape(embed_image)
    batch_size, height, width, channels = shape[0], shape[1], shape[2], shape[3]

    def point_light_distortion():
        px = tf.random.uniform([], minval=0, maxval=width, dtype=tf.int32)
        py = tf.random.uniform([], minval=0, maxval=height, dtype=tf.int32)
        lmin = tf.random.uniform([], minval=0.7, maxval=0.9)
        lmax = tf.random.uniform([], minval=1.1, maxval=1.3)

        x_idx, y_idx = tf.meshgrid(tf.range(width), tf.range(height), indexing='ij')
        dist_to_light = tf.sqrt(tf.cast((x_idx - px) ** 2 + (y_idx - py) ** 2, tf.float32))
        max_dist = tf.sqrt(tf.cast(width ** 2 + height ** 2, tf.float32))

        IWp = (dist_to_light / max_dist) * (lmin - lmax) + lmax
        IWp = tf.expand_dims(IWp, -1)  # 增加通道维度
        return IWp



    def line_light_distortion():
        lmin = tf.random.uniform([], minval=0.7, maxval=0.9, dtype=tf.float32)
        lmax = tf.random.uniform([], minval=1.1, maxval=1.3, dtype=tf.float32)

        ramp = (tf.range(height, dtype=tf.float32) - tf.cast(height, tf.float32)) / tf.cast(height, tf.float32) * (
                    lmin - lmax) + lmin
        ramp = ramp[:, tf.newaxis, tf.newaxis]  # Reshape to [height, 1, 1]

        T0 = tf.tile(ramp, [1, width, 1])  # Tile to [height, width, 1]
        T90 = tf.image.rot90(T0, k=1)
        T180 = tf.image.rot90(T90, k=1)
        T270 = tf.image.rot90(T180, k=1)

        # Here we assume the tensors are already in the shape [height, width, 1] and can be concatenated along the last dimension
        IW = tf.concat([T0, T90, T180, T270], axis=-1)

        # Randomly select one of the rotations
        idx = tf.random.uniform([], minval=0, maxval=4, dtype=tf.int32)
        IW = IW[:, :, idx:idx + 1]  # Select the same slice from each rotation

        return IW

    c = tf.random.uniform([], minval=0, maxval=2, dtype=tf.int32)
    light_distortion = tf.cond(tf.equal(c, 0), point_light_distortion, line_light_distortion)

    light_distortion = tf.expand_dims(light_distortion, 0)
    # light_distortion = tf.expand_dims(light_distortion, -1)
    light_distortion = tf.tile(light_distortion, [batch_size, 1, 1, channels])
    # distorted_image = embed_image * light_distortion

    return light_distortion

def dft_2d(image):
    return tf.signal.fft2d(tf.cast(image, dtype=tf.complex64))


# 2D IDFT
def idft_2d(spectrum):
    return tf.signal.ifft2d(spectrum)


def DFT_standardization(RI):
    # Calculate the mean (μRI) and standard deviation (σRI) of RI
    μRI = tf.reduce_mean(RI)
    σRI = tf.math.reduce_std(RI)

    # Normalize RI using the calculated mean and standard deviation
    RIc = (RI - μRI) / σRI
    return RIc


def compute_weight_matrix(height, width, sigma, beta):
    x = np.linspace(-width // 2, width // 2 - 1, num=width)
    y = np.linspace(-height // 2, height // 2 - 1, num=height)
    x, y = np.meshgrid(x, y)

    g = (1 / (2 * np.pi * sigma**2)) * np.exp(-(x ** 2 + y ** 2) / (2 * sigma ** 2))

    g_normalized = (np.max(g) - g) / (np.max(g) - np.min(g))

    W_F = g_normalized * beta
    if not hasattr(compute_weight_matrix, "first_call"):
        for i in range(400):
            print("")
            for j in range(400):
                print(round(g_normalized[i][j], 2), end=" ")
        compute_weight_matrix.first_call = False

    return W_F


def enhance_frequency(spectrum, W_F):
    return spectrum * tf.cast(W_F, dtype=tf.complex64)

def mse_loss(original, enhanced):
    original = tf.cast(original, dtype=tf.float32)
    enhanced = tf.cast(enhanced, dtype=tf.float32)
    return tf.reduce_mean(tf.square(original - enhanced))


def squeeze_excitation_layer(input_x, out_dim, ratio, layer_name):
    with tf.name_scope(layer_name):
        squeeze = tf.reduce_mean(input_x, axis=[1, 2], keep_dims=True)

        excitation = tf.layers.dense(inputs=squeeze,
                                     units=out_dim / ratio,
                                     activation=tf.nn.relu,
                                     kernel_initializer=tf.contrib.layers.variance_scaling_initializer(),
                                     name=layer_name + '_excitation1')

        excitation = tf.layers.dense(inputs=excitation,
                                     units=out_dim,
                                     activation=tf.nn.sigmoid,
                                     kernel_initializer=tf.contrib.layers.variance_scaling_initializer(),
                                     name=layer_name + '_excitation2')

        excitation = tf.reshape(excitation, [-1, 1, 1, out_dim])

        scale = input_x * excitation

        return scale

class ChannelAttention(tf.layers.Layer):
    def __init__(self, ratio=8, **kwargs):
        super(ChannelAttention, self).__init__(**kwargs)
        self.ratio = ratio

    def build(self, input_shape):
        channel = input_shape[-1]
        self.shared_layer_one = tf.layers.Dense(channel // self.ratio,
                                                activation='relu',
                                                kernel_initializer='he_normal',
                                                use_bias=True,
                                                bias_initializer='zeros')
        self.shared_layer_two = tf.layers.Dense(channel,
                                                kernel_initializer='he_normal',
                                                use_bias=True,
                                                bias_initializer='zeros')
        self.built = True

    def call(self, inputs):
        avg_pool = tf.reduce_mean(inputs, axis=[1, 2], keepdims=True)
        assert avg_pool.get_shape()[1:] == (1, 1, inputs.get_shape()[-1])
        avg_pool = self.shared_layer_one(avg_pool)
        assert avg_pool.get_shape()[1:] == (1, 1, inputs.get_shape()[-1] // self.ratio)
        avg_pool = self.shared_layer_two(avg_pool)
        assert avg_pool.get_shape()[1:] == (1, 1, inputs.get_shape()[-1])

        max_pool = tf.reduce_max(inputs, axis=[1, 2], keepdims=True)
        max_pool = self.shared_layer_one(max_pool)
        max_pool = self.shared_layer_two(max_pool)

        scale = tf.sigmoid(avg_pool + max_pool)
        return inputs * scale


