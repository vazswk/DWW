import bchlib
import glob
from PIL import Image, ImageOps
import os
import numpy as np
import tensorflow as tf
from tensorflow.python.saved_model import tag_constants
from tensorflow.python.saved_model import signature_constants
import tensorflow.compat.v1 as tf
tf.disable_v2_behavior()
# BCH_POLYNOMIAL = 32771
# BCH_BITS = 31

BCH_POLYNOMIAL = 137
BCH_BITS = 5

#300
# BCH_POLYNOMIAL = 8219
# BCH_BITS = 14


def main():
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('model', type=str)
    parser.add_argument('--image', type=str, default=None)
    parser.add_argument('--images_dir', type=str, default='./valid/xxx')
    parser.add_argument('--secret_size', type=int, default=100)
    parser.add_argument('--secret', type=str, default='test')
    args = parser.parse_args()

    if args.image is not None:
        files_list = [args.image]
    elif args.images_dir is not None:
        files_list = glob.glob(args.images_dir + '/*')
    else:
        print('Missing input image')
        return

    height = 400
    width = 400

    sess = tf.InteractiveSession(graph=tf.Graph())

    model = tf.saved_model.loader.load(sess, [tag_constants.SERVING], args.model)

    input_image_name = model.signature_def[signature_constants.DEFAULT_SERVING_SIGNATURE_DEF_KEY].inputs['image'].name
    input_image = tf.get_default_graph().get_tensor_by_name(input_image_name)

    output_secret_name = model.signature_def[signature_constants.DEFAULT_SERVING_SIGNATURE_DEF_KEY].outputs['decoded'].name
    output_secret = tf.get_default_graph().get_tensor_by_name(output_secret_name)

    bch = bchlib.BCH(BCH_POLYNOMIAL, BCH_BITS)

    if args.secret is not None:
        data_1 = bytearray(args.secret + ' ' * (bch.m - len(args.secret)), 'utf-8')
        ecc_1 = bch.encode(data_1)
        packet_1 = data_1 + ecc_1

        packet_binary_1 = ''.join(format(x, '08b') for x in packet_1)
        secret_true = np.array([int(x) for x in packet_binary_1])
        sum = 0
        count = 0
        # print("secret bit:", str(secret_true))

    for filename in files_list:
        if filename.find("residual") != -1 or filename.find("raw") != -1:
            continue
        image = Image.open(filename).convert("RGB")
        image = np.array(ImageOps.fit(image,(height, width)),dtype=np.float32)
        image /= 255.

        feed_dict = {input_image:[image]}

        secret = sess.run([output_secret],feed_dict=feed_dict)[0][0]

        packet_binary = "".join([str(int(bit)) for bit in secret[:(bch.m+bch.ecc_bytes)*8]])
        secret_pred = np.array([int(x) for x in packet_binary])
        packet = bytes(int(packet_binary[i : i + 8], 2) for i in range(0, len(packet_binary), 8))
        packet = bytearray(packet)

        data, ecc = packet[:-bch.ecc_bytes], packet[-bch.ecc_bytes:]

        bitflips = bch.decode_inplace(data, ecc)

        if args.secret is not None:
            bit_acc = 1 - np.sum(np.abs(secret_true - secret_pred)) / np.size(secret_true)
            sum += bit_acc
            count += 1

        if bitflips != -1:
            try:
                code = data.decode("utf-8")
                if args.secret is not None:
                    # bit_acc = 1 - np.sum(np.abs(secret_true - secret_pred)) / np.size(secret_true)
                    print(filename, code, "%.4f%%" % (bit_acc * 100))
                else:
                    print(filename, code)
                continue
            except:
                continue
        if args.secret is not None:
            print(filename, 'Failed to decode', "%.4f%%" % (bit_acc * 100))

        else:
            print(filename, 'Failed to decode')

    if args.secret is not None:
        print('Avg:', "%.4f%%" % (sum / count * 100))
        print(count)


if __name__ == "__main__":
    os.environ['CUDA_VISIBLE_DEVICES'] = "1"
    main()
