%% main
clear; clc;
close all;

photopath = 'D:\workspace\matlab\PerspectiveTransformation\dwt\';
imageFiles = [dir(fullfile(photopath, '*.bmp')); dir(fullfile(photopath, '*.jpg')); dir(fullfile(photopath, '*.png'))];
n = 512; m = 512; % size of the image

for idx = 1:length(imageFiles)
    filename = imageFiles(idx).name;
    fullFileName = fullfile(photopath, filename);
    test_image = im2double(imread(fullFileName));

    %% locate the four corner of the image
    imshow([test_image(:,:,:)]); hold on;
    for p = 1:4
        [loc_x(p),loc_y(p)] = ginput(1);
        plot(loc_x(p),loc_y(p),'r.');
    end
    loc_x = floor(loc_x);
    loc_y = floor(loc_y);

    %% sort the corner
    [X,Y] = my_sort(loc_x, loc_y, test_image);

    %% perspective transformation
    img = imread(fullFileName);
    I = my_pres_trans(img, X, Y, m, n);

    %% write the image
    k = find(filename == '.');
    pathfile = [photopath, [filename(1:k-1), '_re.png']];
    imwrite(I, pathfile);

    % Optional: Close figure after processing each image
    close all;
end
