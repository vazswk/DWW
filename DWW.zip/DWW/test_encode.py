import bchlib
import glob
import os
from main import utils
from PIL import Image,ImageOps
import numpy as np
import tensorflow as tf
import lpips.lpips_tf as lpips_tf
from tensorflow.python.saved_model import tag_constants
from tensorflow.python.saved_model import signature_constants
import tensorflow.compat.v1 as tf
tf.disable_v2_behavior()
# 400
# BCH_POLYNOMIAL = 32771# 137,,8219
# BCH_BITS = 31# 5,,7,31

# 400
# BCH_POLYNOMIAL = 32771# 137,,8219
# BCH_BITS = 18# 5,,7,31

# 100
BCH_POLYNOMIAL = 137
BCH_BITS = 5

height = 400
width = 400

#300
# BCH_POLYNOMIAL = 8219
# BCH_BITS = 14

def transform_net(encoded_image):

    rnd_bri = .3
    rnd_hue = .1
    rnd_noise = .02
    # rnd_noise = .3
    contrast_low = .5
    contrast_high = 1.5
    contrast_low = 1. - (1. - contrast_low) * 1
    contrast_high = 1. + (contrast_high - 1.) * 1
    rnd_sat = 1.
    middle_result = []

    # M = utils.get_rand_transform_matrix(width, np.floor(width * .1), 1)
    # import cv2
    # M = np.zeros((1, 2, 8))
    # src = np.array([[0, 399], [399, 399], [0, 0], [399, 0]], dtype="float32")
    # dst = np.array([[0, 399], [389, 359], [35, 20], [359, 10]], dtype="float32")
    # M0 = np.reshape(cv2.getPerspectiveTransform(dst, src), [-1])
    # M1 = np.reshape(cv2.getPerspectiveTransform(src, dst), [-1])
    # M[0, 0, :] = M1[:-1]
    # M[0, 1, :] = M0[:-1]
    # encoded_image = tf.contrib.image.transform(encoded_image, M[:, 1, :], interpolation='BILINEAR')
    # mask_warped = 1 - tf.contrib.image.transform(tf.ones_like(encoded_image), M[:, 1, :], interpolation='BILINEAR')
    # encoded_image += (1 - mask_warped)
    # middle_result.append(tf.reshape(encoded_image, [height,width,3]))
    # middle_result.append(
    #     tf.reshape(tf.contrib.image.transform(encoded_image, M[:, 1, :], interpolation='BILINEAR') + mask_warped,
    #                [height, width, 3]))

    rnd_brightness = np.random.uniform(-rnd_hue, rnd_hue, (1, 1, 1, 3)) + np.random.uniform(-rnd_bri, rnd_bri, (1, 1, 1, 1))

    jpeg_quality = 100. - tf.random.uniform([]) * 1 * (100. - 25)
    jpeg_factor = tf.cond(tf.less(jpeg_quality, 50), lambda: 5000. / jpeg_quality,
                          lambda: 200. - jpeg_quality * 2) / 100. + .0001

    rnd_noise = np.random.uniform(0, 1) * rnd_noise
    rnd_sat = np.random.uniform(0, 1) * rnd_sat

    # blur
    # f = utils.random_blur_kernel(probs=[.25,.25], N_blur=7,
    #                        sigrange_gauss=[1.,3.], sigrange_line=[.25,1.], wmin_line=3)
    f = utils.random_blur_kernel(probs=[.25, .25], N_blur=7,
                                 sigrange_gauss=[7., 9.], sigrange_line=[.25, 1.], wmin_line=3)
    encoded_image = tf.nn.conv2d(encoded_image, f, [1,1,1,1], padding='SAME')
    # middle_result.append(tf.reshape(encoded_image, [height,width,3]))
    # middle_result.append(
    #     tf.reshape(tf.contrib.image.transform(encoded_image, M[:, 1, :], interpolation='BILINEAR') + mask_warped,
    #                [height, width, 3]))

    contrast_scale = np.random.uniform(contrast_low, contrast_high, (1, 1, 1, 1))

    encoded_image = encoded_image * contrast_scale
    encoded_image = encoded_image + rnd_brightness
    encoded_image = tf.clip_by_value(encoded_image, 0, 1)
    # middle_result.append(tf.reshape(encoded_image, [height,width,3]))
    # middle_result.append(
    #     tf.reshape(tf.contrib.image.transform(encoded_image, M[:, 1, :], interpolation='BILINEAR') + mask_warped,
    #                [height, width, 3]))

    encoded_image_lum = tf.expand_dims(tf.reduce_sum(encoded_image * tf.constant([.3,.6,.1]), axis=3), 3)
    encoded_image = (1 - rnd_sat) * encoded_image + rnd_sat * encoded_image_lum
    # middle_result.append(tf.reshape(encoded_image, [height,width,3]))
    # middle_result.append(
    #     tf.reshape(tf.contrib.image.transform(encoded_image, M[:, 1, :], interpolation='BILINEAR') + mask_warped,
    #                [height, width, 3]))

    noise = tf.random_normal(shape=tf.shape(encoded_image), mean=0.0, stddev=rnd_noise, dtype=tf.float32)
    encoded_image = encoded_image + noise
    encoded_image = tf.clip_by_value(encoded_image, 0, 1)
    # middle_result.append(tf.reshape(encoded_image, [height,width,3]))
    # middle_result.append(
    #     tf.reshape(tf.contrib.image.transform(encoded_image, M[:, 1, :], interpolation='BILINEAR') + mask_warped,
    #                [height, width, 3]))

    # encoded_image = tf.reshape(encoded_image, [-1,height,width,3])
    # encoded_image = tf.contrib.image.transform(encoded_image, M[:, 1, :], interpolation='BILINEAR') + mask_warped

    encoded_image = utils.jpeg_compress_decompress(encoded_image, rounding=tf.round,
                                                   factor=jpeg_factor, downsample_c=True)
    # middle_result.append(tf.reshape(encoded_image, [height, width, 3]))
    # encoded_image = tf.contrib.image.transform(encoded_image, M[:, 0, :], interpolation='BILINEAR')

    return tf.reshape(encoded_image, [height,width,3]), middle_result


def main():
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('model', type=str)
    parser.add_argument('--image', type=str, default=None)
    parser.add_argument('--images_dir', type=str, default='./data/valid')
    parser.add_argument('--save_dir', type=str, default='./data/valid_ans')
    parser.add_argument('--secret', type=str, default='test')
    parser.add_argument('--secret_size', type=int, default=100)
    parser.add_argument('--warp_num', type=int, default=0)
    parser.add_argument('--save_edge', action='store_true')
    args = parser.parse_args()

    if args.image is not None:
        files_list = [args.image]
    elif args.images_dir is not None:
        files_list = glob.glob(args.images_dir + '/*')
    else:
        print('Missing input image')
        return

    sess = tf.InteractiveSession(graph=tf.Graph())

    model = tf.saved_model.loader.load(sess, [tag_constants.SERVING], args.model)

    input_secret_name = model.signature_def[signature_constants.DEFAULT_SERVING_SIGNATURE_DEF_KEY].inputs['secret'].name
    input_image_name = model.signature_def[signature_constants.DEFAULT_SERVING_SIGNATURE_DEF_KEY].inputs['image'].name
    input_secret = tf.get_default_graph().get_tensor_by_name(input_secret_name)
    input_image = tf.get_default_graph().get_tensor_by_name(input_image_name)

    output_stegastamp_name = model.signature_def[signature_constants.DEFAULT_SERVING_SIGNATURE_DEF_KEY].outputs['stegastamp'].name
    output_residual_name = model.signature_def[signature_constants.DEFAULT_SERVING_SIGNATURE_DEF_KEY].outputs['residual'].name
    output_stegastamp = tf.get_default_graph().get_tensor_by_name(output_stegastamp_name)
    output_residual = tf.get_default_graph().get_tensor_by_name(output_residual_name)

    width = 400  # 384
    height = 400  # 384

    bch = bchlib.BCH(BCH_POLYNOMIAL, BCH_BITS)

    if len(args.secret) > bch.m:
        print('Error: Can only encode 56bits (7 characters) with ECC')
        return

    data = bytearray(args.secret + ' '*(bch.m -len(args.secret)), 'utf-8')
    ecc = bch.encode(data)
    packet = data + ecc

    packet_binary = ''.join(format(x, '08b') for x in packet)
    secret = [int(x) for x in packet_binary]
    secret.extend([0, 0, 0, 0])
    # secret.extend([0, 0, 0, 0])
    # secret.extend([0, 0, 0, 0])
    # secret.extend([0, 0, 0, 0])

    if args.save_dir is not None:
        if not os.path.exists(args.save_dir):
            os.makedirs(args.save_dir)
        size = (width, height)
        PSNR = 0
        # LPIPS = 0
        SSIM = 0
        for filename in files_list:
            image = Image.open(filename).convert("RGB")
            save_name = filename.split('/')[-1].split('.')[0]
            image = np.array(ImageOps.fit(image,size),dtype=np.float32)
            image /= 255.

            feed_dict = {input_secret:[secret],
                         input_image:[image]}

            # print(secret.__len__())
            # print(output_stegastamp.shape)
            # print(output_residual.shape)
            hidden_img, residual = sess.run([output_stegastamp, output_residual],feed_dict=feed_dict)
            hidden_img = image + 1.1 * residual
            hidden_img = np.clip(hidden_img, 0, 1)
            residual = 1.1 * residual
            img_tf = tf.convert_to_tensor(image, dtype=tf.float32)
            hidden_img_tensor = tf.convert_to_tensor(hidden_img, dtype=tf.float32)

            psnr = tf.image.psnr(hidden_img, image, max_val=1.0)
            psnr = tf.reduce_mean(psnr).eval()
            lpips_loss_op = tf.reduce_mean(lpips_tf.lpips(image, hidden_img)).eval()
            ssim = tf.image.ssim_multiscale(hidden_img_tensor, img_tf, max_val=1.0)
            ssim = tf.reduce_mean(ssim).eval()
            SSIM = SSIM + ssim
            PSNR += psnr
            LPIPS += lpips_loss_op
            print(psnr)
            print(lpips_loss_op)
            print(ssim)
            rescaled = (hidden_img[0] * 255).astype(np.uint8)
            raw_img = (image * 255).astype(np.uint8)
            residual = residual[0]+.5

            residual = (residual * 255).astype(np.uint8)

            im = Image.fromarray(np.array(raw_img))
            im.save(args.save_dir + '/' + save_name + '_raw.png')

            im = Image.fromarray(np.array(rescaled))
            im.save(args.save_dir + '/'+save_name+'_hidden.png')
            # im.save(args.save_dir + '/' + save_name + '_hidden.jpg', quality=15)

            if args.save_edge:
                edge = utils.get_edge(raw_img, size)
                # edge = np.round(1 - edge)
                edge = 1 - edge
                edge = np.expand_dims(edge, axis=-1)
                edge = np.concatenate((edge, edge, edge), axis=-1)
                im = Image.fromarray(np.uint8(edge * 255))
                im.save(args.save_dir + '/' + save_name + '_edge.png')

            if args.warp_num > 0:
                for i in range(args.warp_num):
                    im_warp, middle_result = sess.run(transform_net(hidden_img))
                    im_warp = Image.fromarray((im_warp * 255).astype(np.uint8))
                    im_warp.save(args.save_dir + '/' + save_name + '_hidden_warp' + str(i) + '.png')
                    # for j, im in enumerate(middle_result):
                    #     im = Image.fromarray((im * 255).astype(np.uint8))
                    #     im.save(args.save_dir + '/' + save_name + '_hidden_warp' + str(i) + '_' + str(j) + '.png')

            im = Image.fromarray(np.squeeze(np.array(residual)))
            im.save(args.save_dir + '/'+save_name+'_residual.png')
        print('Avg:', "%.4f" % (PSNR / len(files_list)))
        print('Avg:', "%.6f" % (LPIPS / len(files_list)))
        print('Avg:', "%.6f" % (SSIM / len(files_list)))

if __name__ == "__main__":
    # os.environ['CUDA_VISIBLE_DEVICES'] = "0"
    main()
